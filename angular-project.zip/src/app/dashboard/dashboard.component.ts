import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
  userData: any[] = [];

  constructor(private router: Router ) { }

  ngOnInit(): void {
    const data = localStorage.getItem('userData');
    if (data) {
      this.userData = JSON.parse(data);
    }
  }

  getStatusColor(status: string): string {
    switch (status) {
      case 'Pending': return 'yellow';
      case 'Approved': return 'green';
      case 'Rejected': return 'red';
      default: return 'black';
    }
  }

  addUser(){
    this.router.navigate(['/form']);
  }

  editUser(index: number) {
    this.router.navigate(['/form'], { queryParams: { editIndex: index } });
  }

  deleteUser(index: number) {
    if (confirm('Are you sure you want to delete this record?')) {
      let storedData = JSON.parse(localStorage.getItem('userData') || '[]');
      storedData.splice(index, 1);
      localStorage.setItem('userData', JSON.stringify(storedData));
      this.userData.splice(index, 1);
    }
  }
}
